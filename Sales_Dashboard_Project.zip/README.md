
# 📊 Sales Dashboard Project (Power BI + SQL)

## 🔥 Project Overview
This project demonstrates how to build an end-to-end sales analytics dashboard using:
- SQL for data storage & querying
- Power BI for visualization

## 📁 Files in this Repository
- customers.csv
- products.csv
- sales.csv
- sales_dashboard.sql

## 🚀 Steps to Run
1. Import CSV files into your SQL database
2. Run sales_dashboard.sql
3. Connect Power BI to the database
4. Build visuals:
   - Total Sales
   - Total Profit
   - Orders
   - Sales Trend
   - Top Products
   - Best Customers
   - Sales by Region

## 🛠 Tools Used
- SQL
- Power BI
- DAX

## 💼 Resume Line
Developed an interactive sales dashboard using SQL and Power BI to analyze revenue trends, customer performance, and regional sales.
