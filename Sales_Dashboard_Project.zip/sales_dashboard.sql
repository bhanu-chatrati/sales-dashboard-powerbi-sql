
-- SALES DASHBOARD PROJECT SQL SCRIPT

CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100),
    region VARCHAR(50)
);

CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    category VARCHAR(50)
);

CREATE TABLE sales (
    order_id INT PRIMARY KEY,
    order_date DATE,
    customer_id INT,
    product_id INT,
    quantity INT,
    sales_amount DECIMAL(10,2),
    profit DECIMAL(10,2),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- KPI Query
SELECT 
    SUM(sales_amount) AS total_sales,
    SUM(profit) AS total_profit,
    COUNT(order_id) AS total_orders
FROM sales;

-- Monthly Sales
SELECT 
    DATENAME(month, order_date) AS month,
    SUM(sales_amount) AS total_sales
FROM sales
GROUP BY DATENAME(month, order_date), MONTH(order_date)
ORDER BY MONTH(order_date);

-- Top Products
SELECT 
    p.product_name,
    SUM(s.sales_amount) AS total_sales
FROM sales s
JOIN products p ON s.product_id = p.product_id
GROUP BY p.product_name
ORDER BY total_sales DESC;
